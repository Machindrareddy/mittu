# -*- coding: utf-8 -*-
"""
Created on Fri Nov 10 07:56:48 2023

@author: Manichandra
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("C:\\Users\\user\\Downloads\\bigmart sales.csv")
df.head()

df.tail()
df.describe()

# Line chart
# Function to create an improved multiple line chart with a different grouping
def plot_improved_line_chart_by_item_type(data, x_column, y_column, groupby_column, title, x_label, y_label):
    """
    Creates an improved multiple line chart grouped by 'Item_Type' instead of 'Outlet_Size'.

    :param data: Pandas DataFrame containing the data.
    :param x_column: The column name for the x-axis.
    :param y_column: The column name for the y-axis.
    :param groupby_column: The column name to group and create multiple lines.
    :param title: The title of the chart.
    :param x_label: The label for the x-axis.
    :param y_label: The label for the y-axis.
    """
    # Group the data by the 'groupby_column' and 'x_column' and calculate the mean of 'y_column'
    grouped_data = data.groupby([groupby_column, x_column])[y_column].mean().unstack(groupby_column)
    
    # Set the color palette
    colors = plt.get_cmap('tab10')

    # Start plotting with a larger figure size for better readability
    plt.figure(figsize=(14, 7))
    for (column, color) in zip(grouped_data.columns, colors.colors):
        plt.plot(grouped_data.index, grouped_data[column], marker='o', color=color, label=column)
    
    plt.title(title, fontsize=16)
    plt.xlabel(x_label, fontsize=12)
    plt.ylabel(y_label, fontsize=12)
    plt.legend(title=groupby_column, bbox_to_anchor=(1.04,1), loc="upper left")
    plt.grid(True)
    plt.xticks(grouped_data.index, rotation=45)  # Rotate x-axis labels for better readability
    plt.tight_layout()  # Adjust layout to make room for the legend
    plt.show()

# Let's use the improved function with the bigmart sales data, now grouping by 'Item_Type'.
plot_improved_line_chart_by_item_type(df,
                                      x_column='Outlet_Establishment_Year',
                                      y_column='Item_Outlet_Sales',
                                      groupby_column='Item_Type',
                                      title='Average Item Sales over the Years by Item Type',
                                      x_label='Year of Establishment',
                                      y_label='Average Item Sales')

#Histogram
# Function to create a histogram
def plot_histogram(data, column, title, x_label, y_label, bins=None, color=None):
    """
    Creates a histogram for a given numerical column in the data.

    :param data: Pandas DataFrame containing the data.
    :param column: The column name for which the histogram will be created.
    :param title: The title of the histogram.
    :param x_label: The label for the x-axis.
    :param y_label: The label for the y-axis.
    :param bins: The number of bins for the histogram. Optional; the default is calculated automatically.
    :param color: The color for the histogram bars. Optional; a default color palette is used if not provided.
    """
    # Let's plot and find out the distribution of our column of interest.
    plt.figure(figsize=(10, 6))
    plt.hist(data[column], bins=bins, color=color)
    
    # Setting up titles and labels. A histogram without labels is like a shop with no signboard!
    plt.title(title, fontsize=16)
    plt.xlabel(x_label, fontsize=12)
    plt.ylabel(y_label, fontsize=12)
    
    # And of course, the grid for better readability.
    plt.grid(axis='y', alpha=0.75)
    
    # Now, let the histogram speak for itself!
    plt.show()

# Now we'll use the histogram function to visualize the distribution of the Item Maximum Retail Price (MRP).
plot_histogram(df,
               column='Item_MRP',
               title='Distribution of Item Maximum Retail Price (MRP)',
               x_label='Item MRP',
               y_label='Frequency',
               bins=30,  # Let's go for 30 bins.
               color='skyblue')  # A soothing sky blue color for our bars.

# Piechart
# Function to create a pie chart
def plot_pie_chart(data, column, title):
    """
    Creates a pie chart for a given categorical column in the data.

    :param data: Pandas DataFrame containing the data.
    :param column: The column name for which the pie chart will be created.
    :param title: The title of the pie chart.
    """
    # First, let's sum up the total sales by the category of interest.
    sales_by_category = data.groupby(column).size()
    
    # Time to plot! Let's bring out the pie (chart), shall we?
    fig, ax = plt.subplots(figsize= (10,8))
    ax.pie(sales_by_category, labels=sales_by_category.index, autopct='%1.1f%%', startangle=90, colors=plt.cm.Paired.colors)
    ax.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
    
    # And what's a pie without a title? Let's add one.
    plt.title(title, fontsize=16)
    
    # Serve the pie chart hot!
    plt.show()

# Now, let's use the pie chart function to visualize the sales distribution by 'Outlet_Type'.
plot_pie_chart(df,
               column='Outlet_Type',
               title='Proportion of Total Sales by Outlet Type')
